// Vergara, Ivyann Romijn H.
// 2020-00761
//Create a program that will take an input ArnoldC file (named input.arnoldc) containing (not necessarily correct) ArnoldC code.

extern crate regex;			// for regex
use regex::Regex;
//use std::error::Error;    // has an error, I can't run the sample file, it says "use of deprecated associated function `std::error::Error::description`: use the Display impl or to_string()"
use std::fs::File;          // file class
use std::io::prelude::*;    // for file reading
use std::path::Path;        // path class
use std::io;                // for input and output

fn main() {
	let path = Path::new("files/input.arnoldc");		                                    // gets the path of the arnoldc file
	let display = path.display();
	let mut file = match File::open(&path){		                                            // opens file with the path of arnoldc
		Err(why) => panic!("couldn't open {}: {}", display, why),                           // will be used if an error occurs, otherwise it will open the file
		Ok(file) => file,
	};
	
	let mut input1 = String::new();		                                                    // creates a mutable string
	match file.read_to_string(&mut input1){		                                            // puts the content of the file into input1
		Err(why) => panic!("couldn't read {}: {}", display, why),
		Ok(input1) => input1,
	};
	
    // for menu 
	let mut choice = String::new();
	println!("[1] Show all numbers\n[2] Show all keywords\n[3] Show all strings\n[4] Show all non-keyword identifiers\n");		
	println!("Enter Choice: ");
	io::stdin().read_line(&mut choice).expect("Error");		                                // asks for user input
	println!("");
	
    // file writing
	let path2 = Path::new("files/output.txt");		                                        // path for the output.txt
    let display2 = path2.display();
	let mut file2 = match File::create(&path2){		                                        // creates a new file
		Err(why) => panic!("couldn't create {}: {}", display2, why),                        // error prompt, otherwise it proceeds to creating a new file
		Ok(file2) => file2,
	};
	

    // functions in the menu
	if choice.trim() == "1" {		                        // Show all numbers
		let re = Regex::new(r"(-\d+|\b\d+)").unwrap();		// regex for matching numbers, both positive and negative. \b for word boundary so it wont detect the naming of variables
		let mut count = 0;                                  // counter for the matches
		for _cap in re.captures_iter(&input1){		        // counts the number of matches
			count = count + 1;
		}
		file2.write_all(b"Count: ").expect("Unable to write data");								// writes "Count"
		file2.write_all(count.to_string().as_bytes()).expect("Unable to write data");			
		file2.write_all(b"\n").expect("Unable to write data");									// error prompt if unable to write count
		
        for cap in re.captures_iter(&input1){													// writes all the identifiers
			file2.write_all(b"Detected identifier: ").expect("Unable to write data");
			file2.write_all(cap.at(0).unwrap().as_bytes()).expect("Unable to write data");
			file2.write_all(b"\n").expect("Unable to write data");                              // error prompt if unable to write the identifiers
		}
		println!("Check 'output.txt' for the result");

	} else if choice.trim() == "2" {		                                                     // Show all keywords
		let mut v1 = Vec::new();                                                                 // create a vector to hold the matches/ captures                                    
		let mut count = 0;                                                                       // counter for the matches
		let re = Regex::new(r#"((?m)^[A-Z’]+[’ A-Z]*)"#).unwrap();		                         // regex for matching keywords, matches all capitals in every new line (?m), also matches words with apostrophe
		
        for cap in re.captures_iter(&input1){			                                         // appends the captured match in the vector, checks if there is a repetition
			if v1.contains(&cap.at(0).unwrap().trim()){
				continue;
			}
			else {		
				v1.push(&cap.at(0).unwrap().trim());
				count = count + 1;                                                              // updates the count
			}
		}
		file2.write_all(b"Count: ").expect("Unable to write data");						        // prints the count into the file, if unable there is an error
		file2.write_all(count.to_string().as_bytes()).expect("Unable to write data");           
		file2.write_all(b"\n").expect("Unable to write data");

		for i in &v1{                                                                           // writes all the matched keywords into the output.txt, error prompt  if unable to add
			file2.write_all(b"Detected identifier: ").expect("Unable to write data");
			file2.write_all(i.as_bytes()).expect("Unable to write data");
			file2.write_all(b"\n").expect("Unable to write data");
		}
		println!("Check 'output.txt' for the result'");

	} else if choice.trim() == "3" {		                                                    // Show all strings
		let re = Regex::new(r#"(".*")"#).unwrap();		                                        // matches the words that is enclosed in ""
		let mut count = 0;                                                                      // counter
		
        for _cap in re.captures_iter(&input1){
			count = count + 1;                                                                  // updates the counter for all matches
		}
		file2.write_all(b"Count: ").expect("Unable to write data");						        // prints the count into the file
		file2.write_all(count.to_string().as_bytes()).expect("Unable to write data");
		file2.write_all(b"\n").expect("Unable to write data");

		for cap in re.captures_iter(&input1){                                                   // prints the string
			file2.write_all(b"Detected identifier: ").expect("Unable to write data");
			file2.write_all(cap.at(0).unwrap().replace("\"", "").as_bytes()).expect("Unable to write data");    // replaces all the "  into null so " wouldn't print in the output.txt
			file2.write_all(b"\n").expect("Unable to write data");                                              // error prompt     
		}
		println!("Check 'output.txt' for the result'");

	} else if choice.trim() == "4" {		                                                    // Show all non - keyword identifiers
		let re = Regex::new(r"([a-z]+[a-z0-9]*\n)").unwrap();		                            // regex for matching every variable including newline
		let mut count = 0;                                                                      // counter
		for _cap in re.captures_iter(&input1){                                                  // updates the counter once a match is found
			count = count + 1;
		}
		file2.write_all(b"Count: ").expect("Unable to write data");							    // prints the count into the output.txt, shows an error if unable 
		file2.write_all(count.to_string().as_bytes()).expect("Unable to write data");           
		file2.write_all(b"\n").expect("Unable to write data");

		for cap in re.captures_iter(&input1){                                                   // prints all the captured identifier
			file2.write_all(b"Detected identifier: ").expect("Unable to write data");
			file2.write_all(cap.at(0).unwrap().trim().as_bytes()).expect("Unable to write data");
			file2.write_all(b"\n").expect("Unable to write data");
		}
		println!("Check 'output.txt' for the result");
	} else {		                                                                            // invalid choice error
		println!("Invalid choice! \n Run the program again.");
	}
}
