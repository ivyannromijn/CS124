use std::io;		// import library for io
#[derive(Debug)]
#[derive(Clone)]	// .clone() function to return a copy of the value

// given structures
struct Artist_Event {
    event_id : u32 ,
    event_title : String ,
    artist : String ,
    datetime : String ,
    ticket_price : f64 ,
    stock : u32
}

struct Customer {
    name : String ,
    tickets_bought : Vec < String > ,
    total_cost : f64
}


// print menu
fn menu_print() {
	println!("==================== MENU ====================");
    println!("[1] Add Event Details");
    println!("[2] Buy Ticket");
    println!("[3] Edit Event Details");
    println!("[4] Delete Event");
    println!("[5] View All Events");
    println!("[6] View All Customers");
    println!("[7] Exit\n");
}

// function for adding new events
// fn add_events(){}

fn main() {
    // empty vector for events and the customers
	let mut events:Vec<Artist_Event> = Vec::new();		
	let mut _customers:Vec<Customer> = Vec::new();			
	loop {
		let mut choice = String::new();		// variable to store choice
		
    	menu_print();		                // calls the menu function
    	println!("Enter Choice:");
    	io::stdin().read_line(&mut choice).expect("Error");		// gets the choice of the user
    	
    	if choice.trim() == "1" {		                        // ADD EVENT DETAILS
            println!("\nEnter event id:");
    		let mut event_id2 = String::new();		            // stores the added event id
    		io::stdin().read_line(&mut event_id2).expect("Error");
    		let event_id2:u32 = event_id2.trim().parse().expect("Error");		// type casts input into u32 and trims off \n, and parses
    		
            // checks if there is a duplicate event id
    		let mut duplicateid = false;
    		for i in 0..(events.len()) {			        // loops through the existing event id		
    			if events[i].event_id == event_id2 {		// if there is duplicate, changeto true
    				duplicateid = true;							
    				break;
    			} else {									// else just continues
    				continue;
    			}
    		}
    		if duplicateid == true{							
    			println!("\nEvent ID already exists!");
    		} else {
                // stores the event title
				println!("Enter event title:");
				let mut title = String::new();		
				io::stdin().read_line(&mut title).expect("Error");
				let title = title.trim();
				
                // stores the artist
				println!("Enter artist:");
				let mut artist2 = String::new();		
				io::stdin().read_line(&mut artist2).expect("Error");
				let artist2 = artist2.trim();
				
                // stores the date and time
				println!("Enter date and time:");
				let mut datetime_2 = String::new();		
				io::stdin().read_line(&mut datetime_2).expect("Error");
				let datetime_2 = datetime_2.trim();
				
                // stores the ticket price
				println!("Enter ticket price:");
				let mut ticket_price2 = String::new();		
				io::stdin().read_line(&mut ticket_price2).expect("Error");
				let ticket_price2:f64 = ticket_price2.trim().parse().expect("Error");
				
                // stores the stock of the tickets
				println!("Enter stock:");
				let mut stocks_2 = String::new();		
				io::stdin().read_line(&mut stocks_2).expect("Error");
				let stocks_2:u32 = stocks_2.trim().parse().expect("Error");
				
                // structure that will hold all info and input values from user
				let concert = Artist_Event{		
			        event_id : event_id2,
                    event_title : title.to_string(),
                    artist : artist2.to_string(),
                    datetime : datetime_2.to_string(),
                    ticket_price : ticket_price2,
                    stock : stocks_2
			    };
				events.push(concert);		// add structure to events vector
				println!("\nSuccessfully added event!");
			}
   	} else if choice.trim() == "2" {		// BUY TICKET
    		if events.len() == 0 {		// checks if there are events available
    			println!("\nThere are no events available!");
    		} else {
                // stores the customer name
				println!("Enter customer name:");
				let mut name2 = String::new();		
				io::stdin().read_line(&mut name2).expect("Error");
				let name2 = name2.trim();

				let mut existingcustomer = false;
				for i in 0..(_customers.len()) {
					if _customers[i].name == name2{		//checks if name is in _customers vector or not, if exists will just open information and allow to buy a ticket
						existingcustomer = true;

                        // prints all available events
						println!("\n-------- EVENTS AVAILABLE --------");
						for j in &events {		
							println!("[{:?}] {} ({}) - {:?}", j.event_id, j.event_title, j.artist, j.ticket_price);
						}

                        // keeps the event id information to be booked
						println!("\nEnter event id to buy:");
						let mut event_id_book = String::new();		
						io::stdin().read_line(&mut event_id_book).expect("Error");
						let event_id_book:u32 = event_id_book.trim().parse().expect("Error");

						let mut existingevent= false;
						for k in 0..(events.len()) {
							if events[k].event_id == event_id_book {		// loops through the events available, if found then it is existing
								existingevent = true;
								if events[k].stock == 0 {		            // checks if there is still a ticket left 
									println!("\nEvent ticket is out of stock !");
								} else {
									let word = events[k].event_id.to_string() + "_" + &events[k].event_title + "_" + &events[k].datetime;		// concatenates strings
									let word2 = word.clone();		             // keeps a copy of word
									_customers[i].tickets_bought.push(word);	// adds the tickets bought to the customer
									_customers[i].total_cost = &_customers[i].total_cost + events[k].ticket_price;		// updates total cost of customer
									events[k].stock = events[k].stock - 1;		//subtracts 1 stock from the ticket
									println!("\nSuccessfully bought ticket {}!", word2);
								}
								break;
							} else {
								continue;
							}
						} if existingevent == false{		//if event id is not found
							println!("\nEvent ID not found!");
						}
						break;
					} else {
						continue;
					}
				}
				if existingcustomer == false {		// when it is a new customer
					let person = Customer {		    // adds new structure of a customer
						name: name2.to_string(),
                        tickets_bought : Vec::new(),
                        total_cost : 0.0
					};
					_customers.push(person);		// adds the details of the person to _customers vector 

                    // prints all available events
                    println!("\n-------- EVENTS AVAILABLE --------");
                    for j in &events {		
                        println!("[{:?}] {} ({}) - {}", j.event_id, j.event_title, j.artist, j.ticket_price);
                    }

                    // keeps the event id information to be booked
					println!("\nEnter event id to buy:");
						let mut event_id_book = String::new();		
						io::stdin().read_line(&mut event_id_book).expect("Error");
						let event_id_book:u32 = event_id_book.trim().parse().expect("Error");

					let mut existingevent2 = false;
					for i in 0..(events.len()) {
						if events[i].event_id == event_id_book {
							existingevent2 = true;
							for j in 0..(_customers.len()) {
								if _customers[j].name == name2{
									if events[i].stock == 0 {
										println!("\nEvent ticket is out of stock !");
									} else {
										let word = events[i].event_id.to_string() + "_" + &events[i].event_title + "_" + &events[i].datetime;		//concatenates strings
										let word2 = word.clone();
										_customers[j].tickets_bought.push(word);
										_customers[j].total_cost = &_customers[j].total_cost + events[i].ticket_price;
										events[i].stock = events[i].stock - 1;
										println!("\nSuccessfully bought ticket {}!", word2);
									}
									break;
								} else {
									continue;
								}
							}
							break;
						} else {
							continue;
						}
					}
					if existingevent2 == false{
						println!("\nEvent ID not found!");
					}
				}
			}
    		
    	} else if choice.trim() == "3" {		// EDIT EVENT DETAILS
    		if events.len() == 0 {
    			println!("\nThere are no events available!");
    		} else {
                // stores the event to be edited
				println!("\nEnter event id:");
				let mut event_id_edit = String::new();		
				io::stdin().read_line(&mut event_id_edit).expect("Error");
				let event_id_edit:u32 = event_id_edit.trim().parse().expect("Error");
				
				let mut existingevent3 = false;
				for i in 0..(events.len()) {		// looks for event id that user wants to edit
					if events[i].event_id == event_id_edit {
						existingevent3 = true;
						
                        // for new date and time
						println!("Enter new date and time:");
						let mut new_datetime = String::new();		
						io::stdin().read_line(&mut new_datetime).expect("Error");
						let new_datetime = new_datetime.trim();
						
                        // for new ticket price
						println!("Enter new ticket price:");
						let mut new_ticket_price = String::new();		
						io::stdin().read_line(&mut new_ticket_price).expect("Error");
						let new_ticket_price:f64 = new_ticket_price.trim().parse().expect("Error");
						
                        // for new stocks
						println!("Enter new stocks:");
						let mut new_stock = String::new();		
						io::stdin().read_line(&mut new_stock).expect("Error");
						let new_stock:u32 = new_stock.trim().parse().expect("Error");
						
                        // updates the old values to new 
						events[i].datetime = new_datetime.to_string();		
						events[i].ticket_price = new_ticket_price;
						events[i].stock = new_stock;
						
						println!("\nEvent Details Successfully Edited!");
						break;
					} else {
						continue;
					}
				}
				if existingevent3 == false{
					println!("\nEvent ID not found!");
				}
    		}
    		
    	} else if choice.trim() == "4" {		// DELETE EVENT
    		if events.len() == 0 {
    			println!("\nThere are no events available!");
    		} else {
                // for the event id to be deleted
				println!("\nEnter event id:");
				let mut event_id_delete = String::new();		
				io::stdin().read_line(&mut event_id_delete).expect("Error");
				let event_id_delete:u32 = event_id_delete.trim().parse().expect("Error");
				
				let mut existingevent4 = false;
				for i in 0..(events.len()) {
					if events[i].event_id == event_id_delete {
						events.remove(i);		// will delete remove the event
						existingevent4 = true;
						println!("\nSuccessfully deleted event detail!");
						break;
					} else {
						continue;
					}
				}
				if existingevent4 == false {
					println!("\nEvent ID not found!");
				}
    		}
    		
    	} else if choice.trim() == "5" {		// VIEW ALL EVENTS
    		if events.len() == 0 {
    			println!("\nThere are no events available!");
    		} else {
				for i in &events {		// iterates over every element in flightsevents vector and prints out each data from every structure in the vector
					println!("\nEvent ID: {:?}", i.event_id);
					println!("Event Title: {}", i.event_title);
					println!("Artist: {}", i.artist);
					println!("Date and Time: {}", i.datetime);
					println!("Ticket Price: {}", i.ticket_price);
					println!("Stock: {:?}\n", i.stock);
				}
    		}
    	} else if choice.trim() == "6" {		// VIEW ALL CUSTOMERS
    		if _customers.len() == 0 {
    			println!("\nThere are no customers yet !");
    		} else {
				for i in &_customers {		//iterates over every element in customers vector and prints out each data from every structure in the vector
					println!("\nCustomer Name: {}", i.name);
					println!("Tickets BookedBought:");
					for j in &i.tickets_bought {
						println!("- {}", j);
					}
					println!("Total Cost: {}", i.total_cost);
				}
			}
    		
    	} else if choice.trim() == "7" {		//choice will exit the program
    		println!("\nGoodbye!");
    		break;
    		
    	} else {		//if choice is not between 1-7
    		println!("\nChoice is not in menu, choose again");
    	}
    }
}
